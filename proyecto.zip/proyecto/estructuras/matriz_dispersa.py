"""
Matriz Dispersa - Doubly linked list in rows and columns
Used to store pixel layers (capas)
"""


class NodoMatriz:
    def __init__(self, fila, columna, color):
        self.fila = fila
        self.columna = columna
        self.color = color  # Hex color string e.g. "#e74c3c"
        self.arriba = None
        self.abajo = None
        self.izquierda = None
        self.derecha = None


class NodoEncabezado:
    def __init__(self, indice):
        self.indice = indice
        self.siguiente = None
        self.anterior = None
        self.acceso = None  # Points to first node in this row/col


class MatrizDispersa:
    def __init__(self):
        self.cabeza_filas = None   # Head of row headers linked list
        self.cabeza_columnas = None  # Head of column headers linked list

    # ── Header helpers ────────────────────────────────────────────────────────

    def _obtener_o_crear_encabezado_fila(self, fila):
        actual = self.cabeza_filas
        anterior = None
        while actual is not None and actual.indice < fila:
            anterior = actual
            actual = actual.siguiente
        if actual is not None and actual.indice == fila:
            return actual
        nuevo = NodoEncabezado(fila)
        nuevo.siguiente = actual
        if actual is not None:
            actual.anterior = nuevo
        if anterior is None:
            self.cabeza_filas = nuevo
        else:
            anterior.siguiente = nuevo
            nuevo.anterior = anterior
        return nuevo

    def _obtener_o_crear_encabezado_columna(self, columna):
        actual = self.cabeza_columnas
        anterior = None
        while actual is not None and actual.indice < columna:
            anterior = actual
            actual = actual.siguiente
        if actual is not None and actual.indice == columna:
            return actual
        nuevo = NodoEncabezado(columna)
        nuevo.siguiente = actual
        if actual is not None:
            actual.anterior = nuevo
        if anterior is None:
            self.cabeza_columnas = nuevo
        else:
            anterior.siguiente = nuevo
            nuevo.anterior = anterior
        return nuevo

    def _obtener_encabezado_fila(self, fila):
        actual = self.cabeza_filas
        while actual:
            if actual.indice == fila:
                return actual
            actual = actual.siguiente
        return None

    def _obtener_encabezado_columna(self, columna):
        actual = self.cabeza_columnas
        while actual:
            if actual.indice == columna:
                return actual
            actual = actual.siguiente
        return None

    # ── Insert ────────────────────────────────────────────────────────────────

    def insertar(self, fila, columna, color):
        enc_fila = self._obtener_o_crear_encabezado_fila(fila)
        enc_col = self._obtener_o_crear_encabezado_columna(columna)

        nuevo = NodoMatriz(fila, columna, color)

        # Insert in row (sorted by column)
        actual = enc_fila.acceso
        anterior_fila = None
        while actual is not None and actual.columna < columna:
            anterior_fila = actual
            actual = actual.derecha
        if actual is not None and actual.columna == columna:
            actual.color = color  # update existing
            return
        nuevo.derecha = actual
        if actual is not None:
            actual.izquierda = nuevo
        if anterior_fila is None:
            enc_fila.acceso = nuevo
        else:
            anterior_fila.derecha = nuevo
            nuevo.izquierda = anterior_fila

        # Insert in column (sorted by row)
        actual_col = enc_col.acceso
        anterior_col = None
        while actual_col is not None and actual_col.fila < fila:
            anterior_col = actual_col
            actual_col = actual_col.abajo
        nuevo.abajo = actual_col
        if actual_col is not None:
            actual_col.arriba = nuevo
        if anterior_col is None:
            enc_col.acceso = nuevo
        else:
            anterior_col.abajo = nuevo
            nuevo.arriba = anterior_col

    def obtener(self, fila, columna):
        enc_fila = self._obtener_encabezado_fila(fila)
        if not enc_fila:
            return None
        actual = enc_fila.acceso
        while actual:
            if actual.columna == columna:
                return actual.color
            if actual.columna > columna:
                break
            actual = actual.derecha
        return None

    def obtener_todos_pixeles(self):
        """Returns list of (fila, columna, color) tuples"""
        pixeles = []
        enc_fila = self.cabeza_filas
        while enc_fila:
            actual = enc_fila.acceso
            while actual:
                pixeles.append((actual.fila, actual.columna, actual.color))
                actual = actual.derecha
            enc_fila = enc_fila.siguiente
        return pixeles

    def obtener_dimensiones(self):
        """Returns (max_fila, max_columna)"""
        max_f = max_c = 0
        enc_fila = self.cabeza_filas
        while enc_fila:
            if enc_fila.indice > max_f:
                max_f = enc_fila.indice
            enc_fila = enc_fila.siguiente
        enc_col = self.cabeza_columnas
        while enc_col:
            if enc_col.indice > max_c:
                max_c = enc_col.indice
            enc_col = enc_col.siguiente
        return max_f, max_c

    def esta_vacia(self):
        return self.cabeza_filas is None

    def superponer(self, otra_matriz):
        """Overlay another matrix on top (otra_matriz pixels win)"""
        enc_fila = otra_matriz.cabeza_filas
        while enc_fila:
            actual = enc_fila.acceso
            while actual:
                self.insertar(actual.fila, actual.columna, actual.color)
                actual = actual.derecha
            enc_fila = enc_fila.siguiente

    def a_dict(self):
        """Returns {(fila, col): color} dict for easy rendering"""
        result = {}
        for f, c, color in self.obtener_todos_pixeles():
            result[(f, c)] = color
        return result
