"""
Árbol Binario de Búsqueda (ABB) para almacenar Capas
"""
from estructuras.matriz_dispersa import MatrizDispersa


class Capa:
    def __init__(self, id_capa):
        self.id_capa = id_capa
        self.matriz = MatrizDispersa()

    def agregar_pixel(self, fila, columna, color):
        self.matriz.insertar(fila, columna, color)

    def __str__(self):
        return f"Capa({self.id_capa})"


class NodoABB:
    def __init__(self, capa: Capa):
        self.capa = capa
        self.izquierdo = None
        self.derecho = None


class ArbolCapas:
    def __init__(self):
        self.raiz = None

    def insertar(self, capa: Capa):
        self.raiz = self._insertar(self.raiz, capa)

    def _insertar(self, nodo, capa):
        if nodo is None:
            return NodoABB(capa)
        if capa.id_capa < nodo.capa.id_capa:
            nodo.izquierdo = self._insertar(nodo.izquierdo, capa)
        elif capa.id_capa > nodo.capa.id_capa:
            nodo.derecho = self._insertar(nodo.derecho, capa)
        else:
            nodo.capa = capa  # update
        return nodo

    def buscar(self, id_capa) -> Capa:
        return self._buscar(self.raiz, id_capa)

    def _buscar(self, nodo, id_capa):
        if nodo is None:
            return None
        if id_capa == nodo.capa.id_capa:
            return nodo.capa
        elif id_capa < nodo.capa.id_capa:
            return self._buscar(nodo.izquierdo, id_capa)
        else:
            return self._buscar(nodo.derecho, id_capa)

    def eliminar(self, id_capa):
        self.raiz = self._eliminar(self.raiz, id_capa)

    def _eliminar(self, nodo, id_capa):
        if nodo is None:
            return None
        if id_capa < nodo.capa.id_capa:
            nodo.izquierdo = self._eliminar(nodo.izquierdo, id_capa)
        elif id_capa > nodo.capa.id_capa:
            nodo.derecho = self._eliminar(nodo.derecho, id_capa)
        else:
            if nodo.izquierdo is None:
                return nodo.derecho
            elif nodo.derecho is None:
                return nodo.izquierdo
            sucesor = self._minimo(nodo.derecho)
            nodo.capa = sucesor.capa
            nodo.derecho = self._eliminar(nodo.derecho, sucesor.capa.id_capa)
        return nodo

    def _minimo(self, nodo):
        while nodo.izquierdo:
            nodo = nodo.izquierdo
        return nodo

    # ── Traversals ────────────────────────────────────────────────────────────

    def inorden(self):
        result = []
        self._inorden(self.raiz, result)
        return result

    def _inorden(self, nodo, result):
        if nodo:
            self._inorden(nodo.izquierdo, result)
            result.append(nodo.capa)
            self._inorden(nodo.derecho, result)

    def preorden(self):
        result = []
        self._preorden(self.raiz, result)
        return result

    def _preorden(self, nodo, result):
        if nodo:
            result.append(nodo.capa)
            self._preorden(nodo.izquierdo, result)
            self._preorden(nodo.derecho, result)

    def postorden(self):
        result = []
        self._postorden(self.raiz, result)
        return result

    def _postorden(self, nodo, result):
        if nodo:
            self._postorden(nodo.izquierdo, result)
            self._postorden(nodo.derecho, result)
            result.append(nodo.capa)

    def esta_vacio(self):
        return self.raiz is None

    def todos(self):
        return self.inorden()
