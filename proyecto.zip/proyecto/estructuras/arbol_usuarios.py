"""
Árbol Binario de Búsqueda para Usuarios
Lista enlazada simple de imágenes por usuario
"""


class NodoListaImagenUsuario:
    def __init__(self, id_imagen):
        self.id_imagen = id_imagen
        self.siguiente = None


class ListaImagenesUsuario:
    """Simple linked list of image IDs for a user"""
    def __init__(self):
        self.cabeza = None

    def agregar(self, id_imagen):
        if self.contiene(id_imagen):
            return False
        nuevo = NodoListaImagenUsuario(id_imagen)
        if self.cabeza is None:
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo
        return True

    def eliminar(self, id_imagen):
        actual = self.cabeza
        anterior = None
        while actual:
            if actual.id_imagen == id_imagen:
                if anterior:
                    anterior.siguiente = actual.siguiente
                else:
                    self.cabeza = actual.siguiente
                return True
            anterior = actual
            actual = actual.siguiente
        return False

    def contiene(self, id_imagen):
        actual = self.cabeza
        while actual:
            if actual.id_imagen == id_imagen:
                return True
            actual = actual.siguiente
        return False

    def obtener_todas(self):
        ids = []
        actual = self.cabeza
        while actual:
            ids.append(actual.id_imagen)
            actual = actual.siguiente
        return ids

    def esta_vacia(self):
        return self.cabeza is None


class Usuario:
    def __init__(self, nombre):
        self.nombre = nombre
        self.lista_imagenes = ListaImagenesUsuario()

    def agregar_imagen(self, id_imagen):
        return self.lista_imagenes.agregar(id_imagen)

    def eliminar_imagen(self, id_imagen):
        return self.lista_imagenes.eliminar(id_imagen)

    def __str__(self):
        return f"Usuario({self.nombre})"


class NodoABBUsuario:
    def __init__(self, usuario: Usuario):
        self.usuario = usuario
        self.izquierdo = None
        self.derecho = None


class ArbolUsuarios:
    def __init__(self):
        self.raiz = None

    def insertar(self, usuario: Usuario):
        self.raiz = self._insertar(self.raiz, usuario)

    def _insertar(self, nodo, usuario):
        if nodo is None:
            return NodoABBUsuario(usuario)
        if usuario.nombre < nodo.usuario.nombre:
            nodo.izquierdo = self._insertar(nodo.izquierdo, usuario)
        elif usuario.nombre > nodo.usuario.nombre:
            nodo.derecho = self._insertar(nodo.derecho, usuario)
        else:
            nodo.usuario = usuario  # update
        return nodo

    def buscar(self, nombre) -> Usuario:
        return self._buscar(self.raiz, nombre)

    def _buscar(self, nodo, nombre):
        if nodo is None:
            return None
        if nombre == nodo.usuario.nombre:
            return nodo.usuario
        elif nombre < nodo.usuario.nombre:
            return self._buscar(nodo.izquierdo, nombre)
        else:
            return self._buscar(nodo.derecho, nombre)

    def eliminar(self, nombre):
        self.raiz = self._eliminar(self.raiz, nombre)

    def _eliminar(self, nodo, nombre):
        if nodo is None:
            return None
        if nombre < nodo.usuario.nombre:
            nodo.izquierdo = self._eliminar(nodo.izquierdo, nombre)
        elif nombre > nodo.usuario.nombre:
            nodo.derecho = self._eliminar(nodo.derecho, nombre)
        else:
            if nodo.izquierdo is None:
                return nodo.derecho
            elif nodo.derecho is None:
                return nodo.izquierdo
            sucesor = self._minimo(nodo.derecho)
            nodo.usuario = sucesor.usuario
            nodo.derecho = self._eliminar(nodo.derecho, sucesor.usuario.nombre)
        return nodo

    def _minimo(self, nodo):
        while nodo.izquierdo:
            nodo = nodo.izquierdo
        return nodo

    def inorden(self):
        result = []
        self._inorden(self.raiz, result)
        return result

    def _inorden(self, nodo, result):
        if nodo:
            self._inorden(nodo.izquierdo, result)
            result.append(nodo.usuario)
            self._inorden(nodo.derecho, result)

    def todos(self):
        return self.inorden()

    def esta_vacio(self):
        return self.raiz is None

    def modificar(self, nombre_antiguo, nombre_nuevo):
        usuario = self.buscar(nombre_antiguo)
        if not usuario:
            return False
        imagenes = usuario.lista_imagenes.obtener_todas()
        self.eliminar(nombre_antiguo)
        nuevo_usuario = Usuario(nombre_nuevo)
        for img_id in imagenes:
            nuevo_usuario.agregar_imagen(img_id)
        self.insertar(nuevo_usuario)
        return True
