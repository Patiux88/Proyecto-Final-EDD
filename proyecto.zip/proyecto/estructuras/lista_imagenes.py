"""
Lista Circular Doblemente Enlazada para Imágenes
Lista Simplemente Enlazada para capas de cada imagen
"""


# ── Layer list node (pointer to Capa in ABB) ─────────────────────────────────

class NodoListaCapa:
    def __init__(self, capa_ref):
        self.capa_ref = capa_ref  # Pointer (reference) to Capa object in ABB
        self.siguiente = None


class ListaCapasImagen:
    """Singly linked list of layer references for an image (insertion order = overlay order)"""
    def __init__(self):
        self.cabeza = None
        self.tamanio = 0

    def agregar(self, capa_ref):
        nuevo = NodoListaCapa(capa_ref)
        if self.cabeza is None:
            self.cabeza = nuevo
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo
        self.tamanio += 1

    def obtener_capas_en_orden(self):
        """Returns list of Capa references in overlay order"""
        capas = []
        actual = self.cabeza
        while actual:
            capas.append(actual.capa_ref)
            actual = actual.siguiente
        return capas

    def contiene(self, id_capa):
        actual = self.cabeza
        while actual:
            if actual.capa_ref.id_capa == id_capa:
                return True
            actual = actual.siguiente
        return False

    def eliminar_capa(self, id_capa):
        actual = self.cabeza
        anterior = None
        while actual:
            if actual.capa_ref.id_capa == id_capa:
                if anterior:
                    anterior.siguiente = actual.siguiente
                else:
                    self.cabeza = actual.siguiente
                self.tamanio -= 1
                return True
            anterior = actual
            actual = actual.siguiente
        return False

    def esta_vacia(self):
        return self.cabeza is None


# ── Image ─────────────────────────────────────────────────────────────────────

class Imagen:
    def __init__(self, id_imagen):
        self.id_imagen = id_imagen
        self.lista_capas = ListaCapasImagen()

    def agregar_capa(self, capa_ref):
        if not self.lista_capas.contiene(capa_ref.id_capa):
            self.lista_capas.agregar(capa_ref)
            return True
        return False

    def __str__(self):
        return f"Imagen({self.id_imagen})"


# ── Circular doubly linked list for images ────────────────────────────────────

class NodoImagen:
    def __init__(self, imagen: Imagen):
        self.imagen = imagen
        self.siguiente = None
        self.anterior = None


class ListaCircularImagenes:
    def __init__(self):
        self.cabeza = None
        self.tamanio = 0

    def insertar_ordenado(self, imagen: Imagen):
        nuevo = NodoImagen(imagen)
        if self.cabeza is None:
            self.cabeza = nuevo
            nuevo.siguiente = nuevo
            nuevo.anterior = nuevo
            self.tamanio += 1
            return True

        # Check duplicates
        if self.buscar(imagen.id_imagen) is not None:
            return False

        # Find insertion point (sorted by id)
        actual = self.cabeza
        while True:
            if imagen.id_imagen < actual.imagen.id_imagen:
                # Insert before actual
                prev = actual.anterior
                prev.siguiente = nuevo
                nuevo.anterior = prev
                nuevo.siguiente = actual
                actual.anterior = nuevo
                if actual == self.cabeza:
                    self.cabeza = nuevo
                self.tamanio += 1
                return True
            if actual.siguiente == self.cabeza:
                break
            actual = actual.siguiente

        # Insert at end
        ultimo = self.cabeza.anterior
        ultimo.siguiente = nuevo
        nuevo.anterior = ultimo
        nuevo.siguiente = self.cabeza
        self.cabeza.anterior = nuevo
        self.tamanio += 1
        return True

    def buscar(self, id_imagen) -> Imagen:
        if not self.cabeza:
            return None
        actual = self.cabeza
        while True:
            if actual.imagen.id_imagen == id_imagen:
                return actual.imagen
            actual = actual.siguiente
            if actual == self.cabeza:
                break
        return None

    def eliminar(self, id_imagen):
        if not self.cabeza:
            return False
        actual = self.cabeza
        while True:
            if actual.imagen.id_imagen == id_imagen:
                if self.tamanio == 1:
                    self.cabeza = None
                else:
                    actual.anterior.siguiente = actual.siguiente
                    actual.siguiente.anterior = actual.anterior
                    if actual == self.cabeza:
                        self.cabeza = actual.siguiente
                self.tamanio -= 1
                return True
            actual = actual.siguiente
            if actual == self.cabeza:
                break
        return False

    def obtener_todas(self):
        """Returns list of all Imagen objects in order"""
        if not self.cabeza:
            return []
        result = []
        actual = self.cabeza
        while True:
            result.append(actual.imagen)
            actual = actual.siguiente
            if actual == self.cabeza:
                break
        return result

    def esta_vacia(self):
        return self.cabeza is None
